﻿using FluentValidation;
using System;
using Users.Application.Users.Commands.CreateUser;

namespace Users.Application
{
	public static class ApplicationExtensions
	{
		public static IServiceCollection AddApplication(this IServiceCollection services)
		{
			services.AddScoped<IValidator<CreateUserCommand>, CreateUserCommandValidator>();

			return services;
		}
	}
}
