﻿using FluentResults;
using MediatR;
using Users.Domain.ValueObjects;

namespace Users.Application.Users.Commands.CreateUser
{
	public class CreateUserCommand : IRequest<Result<Guid>>
	{
		public string UserName;

		public string Email;

		public string Password;
		public CreateUserCommand(string userName, string email, string password)
		{
			UserName = userName;
			Email = email;
			Password = password;
		}
	}
}
