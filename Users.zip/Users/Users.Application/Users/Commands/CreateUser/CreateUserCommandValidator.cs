﻿using FluentValidation.AspNetCore;
using FluentValidation;
using Users.Domain.Entities;

namespace Users.Application.Users.Commands.CreateUser
{
	public class CreateUserCommandValidator : AbstractValidator<CreateUserCommand>
	{
		public CreateUserCommandValidator() 
		{
			RuleFor(x => x.UserName)
				.NotEmpty().WithMessage("UserName is required")
				.MaximumLength(12).WithMessage("Maximum lenght is 12");

			RuleFor(x => x.Email)
				.NotEmpty().WithMessage("Email is required")
				.EmailAddress().WithMessage("Email must be valid email adress");

			RuleFor(x => x.Password)
				.NotEmpty().WithMessage("Password is required")
				.MinimumLength(6).WithMessage("Password must be at least 6 characters long");
		}
	}
}
