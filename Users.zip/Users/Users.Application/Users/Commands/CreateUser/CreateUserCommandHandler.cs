﻿using FluentResults;
using MediatR;
using Users.Domain.ValueObjects;

namespace Users.Application.Users.Commands.CreateUser
{
	public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, Result<Guid>>
	{
		public async Task<Result<Guid>> Handle(CreateUserCommand request, CancellationToken cancellationToken)
		{
			var emailParseResult = Email.TryParse(request.Email, out var email);

			if (!emailParseResult)
			{
				return Result.Fail<Guid>("Invalid email format");
			}


		}
	}
}
