﻿namespace Users.Application.Abstractions
{
	public interface IPermissionService
	{
		Task<HashSet<Users.Application.Enums.Permission>> GetPermissionsAsync(Guid userId);
	}
}
