﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Users.Application.Abstractions;
using Users.Domain.Interfaces.Repositories;


namespace Users.Application.Services
{
	public class PermissionService : IPermissionService
	{
		private readonly IUserRepository _usersRepository;

		public PermissionService(IUserRepository usersRepository)
		{
			_usersRepository = usersRepository;
		}

		public Task<HashSet<Users.Application.Enums.Permission>> GetPermissionsAsync(Guid userId)
		{
			return _usersRepository.GetUserPermissions(userId);
		}
	}
}
