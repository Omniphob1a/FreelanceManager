﻿using Users.Domain.Entities;

namespace Users.Domain.Interfaces.Repositories
{
	public interface IRoleRepository
	{
		Task Add(Role role, CancellationToken cancellationToken);
		Task Delete(Guid id, CancellationToken cancellationToken);
		Task Update(Role role, CancellationToken cancellationToken);
        Task GetByName(string name, CancellationToken cancellationToken);
		Task GetById(Guid id, CancellationToken cancellationToken);
		Task ExistsByName(string name, CancellationToken cancellationToken);
	}
}
