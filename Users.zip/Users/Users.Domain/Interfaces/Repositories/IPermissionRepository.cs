﻿using Users.Domain.ValueObjects;

namespace Users.Domain.Interfaces.Repositories
{
	public interface IPermissionRepository
	{
		Task Add(Permission permission, CancellationToken cancellationToken);
		Task Delete(Guid id, CancellationToken cancellationToken);
		Task Update(Permission permission, CancellationToken cancellationToken);
		Task GetByName(string name, CancellationToken cancellationToken);
		Task GetById(Guid id, CancellationToken cancellationToken);
		Task ExistsByName(string name, CancellationToken cancellationToken);
		Task<Permission> GetAll(CancellationToken cancellationToken);
	}
}
