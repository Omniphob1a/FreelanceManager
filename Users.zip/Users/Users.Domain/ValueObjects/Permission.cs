using Users.Domain.Entities;

namespace Users.Domain.ValueObjects;

public class Permission
{
    public string Name { get; set; } = string.Empty;

	public Permission(string name)
	{
		if (string.IsNullOrEmpty(name)) throw new ArgumentNullException(nameof(name), "Permission cannot be empty");
		Name = name;
	}

	public override bool Equals(Object obj)
	{
		return obj is Permission other &&
			   StringComparer.Ordinal.Equals(Name, other.Name);
	}

	public override int GetHashCode() => Name.GetHashCode();
}
