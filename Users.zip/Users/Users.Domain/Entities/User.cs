﻿using FluentResults;
using System;
using Users.Domain.ValueObjects;

namespace Users.Domain.Entities;
public class User
{
	public Guid Id { get; set; }
	public string UserName { get; private set; } = string.Empty;
	public string PasswordHash { get; private set; } = string.Empty;
	public Email Email { get; private set; }
	public DateTime CreatedAt { get; private set; }
	public ICollection<Guid> RoleIds { get; set; } = [];

	public User() { }

	public static Result<User> TryCreate(
			string userName,
			string passwordHash,
			Email email)
	{
		var result = Result.Ok();

		if (string.IsNullOrWhiteSpace(userName))
			result = result.WithError("Username cannot be empty");

		if (email is null)
			result = result.WithError("Email cannot be empty");

		if (string.IsNullOrWhiteSpace(passwordHash))
			result = result.WithError("PasswordHash cannot be empty");

		if (result.IsFailed)
			return result;

		var user = new User
		{
			Id = Guid.NewGuid(),
			UserName = userName,
			PasswordHash = passwordHash,
			Email = email,
			CreatedAt = DateTime.UtcNow
		};

		return Result.Ok(user);
	}

	public void AssignRole(Guid roleId)
	{
		if (!RoleIds.Contains(roleId))
			RoleIds.Add(roleId);
	}

	public void RemoveRole(Guid roleId)
			=> RoleIds.Remove(roleId);
}   

