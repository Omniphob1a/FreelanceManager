﻿using System.Security;
using Users.Domain.ValueObjects;

namespace Users.Domain.Entities;
public class Role
{
    public Guid Id { get; set; }

    public string Name { get; set; } = string.Empty;
	public ICollection<Permission> Permissions { get; set; } = [];

	public Role(string name)
	{
		Id = Guid.NewGuid();
		Name = name;
	}

	public void AddPermission(Permission permission)
	{
		if (!Permissions.Contains(permission))
			Permissions.Add(permission);
	}
	public void RemovePermission(Permission p)
			=> Permissions.Remove(p);
}