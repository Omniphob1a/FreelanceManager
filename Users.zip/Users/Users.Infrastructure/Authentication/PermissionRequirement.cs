﻿using Microsoft.AspNetCore.Authorization;
using Users.Application.Enums;


namespace Users.Infrastructure.Authentication;

public class PermissionRequirement(Permissions[] permissions)
	: IAuthorizationRequirement
{
	public Permissions[] Permissions { get; set; } = permissions;
}