﻿namespace Users.Infrastructure.Authentication;

public class CustomClaims
{
	public const string UserId = "userId";
}