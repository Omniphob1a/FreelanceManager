﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Users.Domain.Entities;
using Users.Domain.ValueObjects;
using Users.Infrastructure.Models;

namespace Users.Infrastructure.Data
{
	public class UsersDbContext(DbContextOptions<UsersDbContext> options) : DbContext(options)
	{
		public DbSet<UserData> Users { get; set; } = null!;
		public DbSet<RoleEntity> Roles { get; set; } = null!;
		public DbSet<PermissionEntity> Permissions { get; set; } = null!;
		public DbSet<UserRoleEntity> UserRoles { get; set; } = null!;
		public DbSet<RolePermissionEntity> RolePermissions { get; set; } = null!;

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.ApplyConfigurationsFromAssembly(typeof(UsersDbContext).Assembly);

			modelBuilder.Entity<PermissionEntity>().HasData(
				new PermissionEntity { Id = Guid.Parse("11111111-1111-1111-1111-111111111111"), Name = Permission.ManageUsers.Value },
				new PermissionEntity { Id = Guid.Parse("22222222-2222-2222-2222-222222222222"), Name = Permission.DeletePosts.Value }
	);

			modelBuilder.Entity<RoleEntity>().HasData(
				new RoleEntity { Id = Guid.Parse("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"), Name = "Admin" }
			);

			modelBuilder.Entity<RolePermissionEntity>().HasData(
				new { RoleId = Guid.Parse("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"), PermissionId = Guid.Parse("11111111-1111-1111-1111-111111111111") },
				new { RoleId = Guid.Parse("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"), PermissionId = Guid.Parse("22222222-2222-2222-2222-222222222222") }
			);

			base.OnModelCreating(modelBuilder);
		}

	}
}
