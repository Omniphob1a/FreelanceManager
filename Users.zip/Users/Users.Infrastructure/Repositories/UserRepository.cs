﻿using FluentResults;
using Microsoft.EntityFrameworkCore;
using Users.Domain.Entities;
using Users.Domain.Interfaces.Repositories;
using Users.Domain.ValueObjects;
using Users.Infrastructure.Data;
using Users.Infrastructure.Models;

namespace Users.Infrastructure.Repositories
{
	public class UserRepository : IUserRepository
	{
		private readonly UsersDbContext _context;

		public UserRepository(UsersDbContext context)
		{
			_context = context;
		}

		public async Task Add(User user, CancellationToken cancellationToken)
		{
			var userData = new UserData
			{
				Id = user.Id,
				UserName = user.UserName,
				Email = user.Email.Value,
				PasswordHash = user.PasswordHash,
				CreatedAt = user.CreatedAt
			};

			foreach (var roleId in user.RoleIds)
				userData.UserRoles.Add(new UserRoleEntity { UserId = userData.Id, RoleId = roleId });

			await _context.AddAsync(userData, cancellationToken);
			await _context.SaveChangesAsync(cancellationToken);
		}

		public async Task<bool> ExistsByEmailAsync(string email, CancellationToken cancellationToken)
		{
			return await _context.Users
				.AsNoTracking()
				.AnyAsync(u => u.Email == email, cancellationToken);
		}

		public async Task<User?> GetByEmail(string email, CancellationToken cancellationToken)
		{
			var userData = await _context.Users
				.Include(u => u.UserRoles)
				.FirstOrDefaultAsync(u => u.Email == email, cancellationToken);

			if (userData == null)
			{
				return null;
			}

			var emailVo = new Email(userData.Email);

			var userСreationResult = User.TryCreate(userData.UserName, userData.PasswordHash, emailVo);

			if (userСreationResult.IsFailed)
			{
				foreach (var error in userСreationResult.Errors)
				{
					Console.WriteLine($"Ошибка: {error.Message}");
				}

				return null;
			}

			var user = userСreationResult.Value;

			foreach (var ur in userData.UserRoles)
				user.AssignRole(ur.RoleId);

			return user;
		}

		public async Task<User?> GetById(Guid id, CancellationToken cancellationToken)
		{
			var userData = await _context.Users
				.Include(u => u.UserRoles)
				.FirstOrDefaultAsync(u => u.Id == id, cancellationToken);

			if (userData == null)
			{
				return null;
			}

			var emailVo = new Email(userData.Email);

			var userCreationResult = User.TryCreate(userData.UserName, userData.PasswordHash, emailVo);

			if (userCreationResult.IsFailed)
			{
				foreach (var error in userCreationResult.Errors)
				{
					Console.WriteLine($"Ошибка {error.Message}");
				}

				return null;
			}

			var user = userCreationResult.Value;

			foreach (var ur in userData.UserRoles)
				user.AssignRole(ur.RoleId);

			return user;
		}

		public async Task Update(User user, CancellationToken cancellationToken)
		{
			var userData = await _context.Users
				.Include(u => u.UserRoles)
				.FirstOrDefaultAsync(u => u.Id == user.Id, cancellationToken);

			if (userData == null)
			{
				throw new InvalidOperationException("User not found");
			}

			userData.UserName = user.UserName;
			userData.PasswordHash = user.PasswordHash;
			userData.Email = user.Email.Value;

			userData.UserRoles.Clear();
			
			foreach (var roleId in user.RoleIds)
			{
				userData.UserRoles.Add(new UserRoleEntity { UserId = userData.Id, RoleId = roleId });
			}

			await _context.SaveChangesAsync(cancellationToken);
		}

		public async Task Delete(Guid id, CancellationToken cancellationToken)
		{
			await _context.Users
				.Where(u => u.Id == id)
				.ExecuteDeleteAsync(cancellationToken);
		}
	}
}
