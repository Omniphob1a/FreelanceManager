﻿using Users.Domain.Entities;
using Users.Domain.Interfaces.Repositories;
using Users.Infrastructure.Data;
using Users.Infrastructure.Models;

namespace Users.Infrastructure.Repositories
{
	public class RoleRepository : IRoleRepository
	{
		private readonly UsersDbContext _context;

		public RoleRepository(UsersDbContext context)
		{
			_context = context;
		}

		public async Task Add(Role role, CancellationToken cancellationToken)
		{
			var roleData = new RoleEntity
			{
				Id = role.Id,
				Name = role.Name
			};

			foreach (var permission in role.Permissions)
			{
				roleData.RolePermissions.Add(new RolePermissionEntity { RoleId = role.Id, PermissionId = permission.})
			}

			await _context.Roles.AddAsync(roleData, cancellationToken);
			await _context.SaveChangesAsync(cancellationToken);
		}

		public async Task Delete(Guid id, CancellationToken cancellationToken)
		{
			throw new NotImplementedException();
		}

		public async Task ExistsByName(string name, CancellationToken cancellationToken)
		{
			throw new NotImplementedException();
		}

		public async Task GetById(Guid id, CancellationToken cancellationToken)
		{
			throw new NotImplementedException();
		}

		public async Task GetByName(string name, CancellationToken cancellationToken)
		{
			throw new NotImplementedException();
		}

		public async Task Update(Role role, CancellationToken cancellationToken)
		{
			throw new NotImplementedException();
		}
	}
}
